<?php 

require_once("../config/config.php");
require_once("../src/vendor/autoload.php");


// require_once '../app/controller/class.home.php';
// require_once '../app/model/class.home.php';


// use App\controller\ControllerHome;

// $c = new ControllerHome();

// use App\controller\controllerTeste;

// $x = new ControllerTeste();

use App\Dispatch;

$index = new Dispatch();

 ?>