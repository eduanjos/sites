<main>
	<section class="container">
		<div class="embed-responsive embed-responsive-21by9">
			<video autoplay muted loop id="myVideo" style="">
			<source src="<?=DIRVIDEO?>tratassauro.mp4" type="video/mp4">
		</video>
		</div>
	</section>
</main>