<script src="<?=DIRLIB?>modernizr-custom.js"></script>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.compat.css">
<!-- WOW CDN First load wow.js and other libraries -->
<script src="<?=DIRLIB?>wow-master-min.js"></script>

<script src="<?=DIRLIB?>scroolspy.js"></script>